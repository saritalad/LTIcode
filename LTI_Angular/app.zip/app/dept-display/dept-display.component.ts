import { Component, OnInit } from '@angular/core';
import { IDept } from '../idept';
import { DeptServiceService } from '../dept-service.service';
import { ActivatedRoute, Router } from '@angular/router';
@Component({
  selector: 'app-dept-display',
  templateUrl: './dept-display.component.html',
  styleUrls: ['./dept-display.component.css']
})
export class DeptDisplayComponent implements OnInit {
  deptdata: IDept = { id: 0, deptname: '', location: '' };
  id: number = 0;
  constructor(private deptservice: DeptServiceService, private router: ActivatedRoute) {

  }

  ngOnInit(): void {
    const tid = this.router.snapshot.paramMap.get('id');
    this.id = Number(tid);
    this.getDeptInfo(this.id);
  }
  getDeptInfo(id: number) {
    this.deptservice.getDept(id).subscribe((data: IDept) => {
      this.deptdata = data;
    })
  }

}
