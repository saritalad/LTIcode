export interface IDept {
    id:number;
    deptname:string;
    location:string;
}
