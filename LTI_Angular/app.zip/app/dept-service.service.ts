import { Injectable } from '@angular/core';
import { IDept } from './idept';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { catchError, Observable, throwError } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class DeptServiceService {
  url = 'http://localhost:9493/api/dept/';
  httpOptions = { headers: new HttpHeaders({ 'Content-type': 'application/json' }) };

  constructor(private http: HttpClient) { }
  // service method for getting all the dept data
  getDeptList(): Observable<any[]> {
    return this.http.get<any[]>(this.url + "list");
  }
  //service method to get one dept
  getDept(id: number): Observable<IDept> {
    return this.http.get<IDept>(this.url + "list/" + id).pipe(catchError(this.handleError));
  }
  addDept(dept:IDept):Observable<IDept>{
    return this.http.post<IDept>(this.url+"AddDept",dept,this.httpOptions).pipe(catchError(this.handleError));
  }
  editDept(dept:IDept):Observable<IDept>{
    return this.http.put<IDept>(this.url+"EditDept/"+dept.id,dept,this.httpOptions).pipe(catchError(this.handleError));
  }
  handleError(error:HttpErrorResponse){
    let errorMessage="";
    errorMessage=error.status +'\n'+error.statusText+'\n'+error.error;
    alert(errorMessage);
    return throwError(errorMessage);
  }
}
// componnent will call the service method--- service method will make a request to web api