import { Component, OnInit } from '@angular/core';
import { DeptServiceService } from '../dept-service.service';
@Component({
  selector: 'app-dept-list',
  templateUrl: './dept-list.component.html',
  styleUrls: ['./dept-list.component.css']
})
export class DeptListComponent implements OnInit {
  deptlist: any[] = [];
  constructor(private deptservice: DeptServiceService) {
    this.deptservice.getDeptList().subscribe(data => { this.deptlist = data; console.log(data) })
  }

  ngOnInit(): void {
  }

}
