import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { DeptAddComponent } from './dept-add/dept-add.component';
import { DeptListComponent } from './dept-list/dept-list.component';
import { DeptEditComponent } from './dept-edit/dept-edit.component';
import { DeptDeleteComponent } from './dept-delete/dept-delete.component';
import { DeptDisplayComponent } from './dept-display/dept-display.component';
import { FormsModule } from '@angular/forms';
@NgModule({
  declarations: [
    AppComponent,
    DeptAddComponent,
    DeptListComponent,
    DeptEditComponent,
    DeptDeleteComponent,
    DeptDisplayComponent
  ],
  imports: [
    BrowserModule,HttpClientModule,
    AppRoutingModule,FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
