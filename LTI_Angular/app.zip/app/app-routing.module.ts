import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DeptAddComponent } from './dept-add/dept-add.component';
import { DeptEditComponent } from './dept-edit/dept-edit.component';
import { DeptListComponent } from './dept-list/dept-list.component';
import { DeptDeleteComponent } from './dept-delete/dept-delete.component';
import { DeptDisplayComponent } from './dept-display/dept-display.component';

const routes: Routes = [
  { path: 'add', component: DeptAddComponent },
  { path: 'edit/:id', component: DeptEditComponent },
  { path: 'delete/:id', component: DeptDeleteComponent },
  { path: 'display/:id', component: DeptDisplayComponent },
  { path: 'list', component: DeptListComponent },

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

//npm install -g @angular/cli
// ng g c dept-add
// dept-list
// dept-edit
//dept-delete
//dept-display

//