import { Component, OnInit } from '@angular/core';
import { IDept } from '../idept';
import { FormsModule } from '@angular/forms';
import { DeptServiceService } from '../dept-service.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-dept-add',
  templateUrl: './dept-add.component.html',
  styleUrls: ['./dept-add.component.css']
})
export class DeptAddComponent implements OnInit {
  dept: IDept = { id: 0, deptname: '', location: '' };
  constructor(private deptservice: DeptServiceService, private route: Router) { }
  addDept() {
    this.deptservice.addDept(this.dept).subscribe(
      () => {
        alert("Record Successfully Added");
        this.route.navigate(['/list']);
      }
    )
  }
  saveDept(dept:IDept):void{
    this.dept=dept;
    this.addDept();
  }
  ngOnInit(): void {
  }

}
