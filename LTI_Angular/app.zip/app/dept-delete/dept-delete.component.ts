import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dept-delete',
  templateUrl: './dept-delete.component.html',
  styleUrls: ['./dept-delete.component.css']
})
export class DeptDeleteComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
