import { Component, OnInit } from '@angular/core';
import { IDept } from '../idept';
import { DeptServiceService } from '../dept-service.service';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-dept-edit',
  templateUrl: './dept-edit.component.html',
  styleUrls: ['./dept-edit.component.css']
})
export class DeptEditComponent implements OnInit {
  dept: IDept = { id: 0, deptname: '', location: '' }
  id: number = 0;

  constructor(private deptservice: DeptServiceService, private route: ActivatedRoute, private router: Router) { }

  ngOnInit(): void {
    const tid = this.route.snapshot.paramMap.get('id');
    this.id = Number(tid);
    this.getDept(this.id);
  }
  getDept(id: number) {
    this.deptservice.getDept(id).subscribe((data: IDept) => this.dept = data);
  }
  saveDept(dept: IDept) {
    this.dept = dept;
    this.deptservice.editDept(this.dept).subscribe(() => {
      alert("Recorded Edited");
      this.router.navigate(['/list']);
    });
  }
}
