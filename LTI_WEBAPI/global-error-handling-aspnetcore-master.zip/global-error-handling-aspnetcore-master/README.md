# global-error-handling-aspnetcore -start

https://code-maze.com/global-error-handling-aspnetcore